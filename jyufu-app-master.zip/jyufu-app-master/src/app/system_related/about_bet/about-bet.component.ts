import { Component } from '@angular/core';
@Component({
    selector: 'about-bet',
    templateUrl: 'about-bet.component.html'
})

export class AboutBetComponent {
    constructor() { 
    }
 
}