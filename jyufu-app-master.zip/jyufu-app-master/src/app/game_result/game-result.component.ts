import { Component, OnInit } from '@angular/core';
import { GlobalService, ApiService } from 'service';

@Component({
    selector: 'game-result-page',
    templateUrl: 'game-result.component.html'
})
//賽事結果
export class GameResultComponent implements OnInit {
    constructor(private globals: GlobalService, public api: ApiService) { }

    /**
     * 680回傳參數
     */
    public gameResult : Array<any> = [];
    /**
     * 搜尋日期
     */
    public searchDate : string = "";

    /**
     * 收尋日期
     * @param _time 時間 格式yyyy-MM-dd
     */
    search(){
        this.getResultData(this.searchDate);
    }
    /**
     * 賽事结果 680 api
     * @param _searchDate  查詢日期
     */
    getResultData(_searchDate : string){
        //               uid:  使用者憑證                  ， lang: string   語系            ，  date:   日期      ， gtype: 球種 
        let parameter= { uid: this.globals.getNowUid(), lang: this.globals.getNowLang(),  date: _searchDate ,gtype:  'FT' };
        this.api.postServer(680, parameter).subscribe(res => {
            if(!res.err){
                console.log("賽事结果",res);
                return;
            } 
            this.gameResult = res.ret.map(item => {
                                        item['lname'] = item['lname'] == null ? "" : item['lname'];
                                        item.PD       = item.PD == '-1--1' ? "赛事取消" : item.PD;
                                        item.PDHR     = item.PDHR == '-1--1' ? "赛事取消" : item.PDHR;
                                        item.am       = item.am == -2 ? "赛事取消" : item.am;               
                                        return item;
                                    });
        });
    }


    /**
     * 一骰進入執行 預設今天
     */
    ngOnInit() {
        //                現在時間 yyyy-mm-dd   toISOString(ie9)
        this.searchDate = new Date().toISOString().substring(0, 10);
        this.getResultData(this.searchDate);
    }
}