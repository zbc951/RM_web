
declare var url: {
    gateway: string,
    lang: string,
    defaultBallType:string
};

declare var getRegistUrl : string;
declare var getOpenWin : string;
declare var getScoreLink : string;
declare var getOnlineLink : string;
declare var getDepositUrl :string;
export let configData = url;
export let registUrl = getRegistUrl;
export let openWin = getOpenWin;
export let scoreLink = getScoreLink;
export let onlineLink = getOnlineLink;