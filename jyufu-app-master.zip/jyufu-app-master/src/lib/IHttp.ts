export interface ResponseData {

}

export interface RequestData {

}