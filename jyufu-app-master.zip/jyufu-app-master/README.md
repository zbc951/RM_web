# taogin_app
大球-掏金網 電腦版前端
npm run start
npm run build

run css command: 
       在command 打 gulp(gulp default) 的指令 就可以自動編輯scss壓縮成一隻css 
         C:\code\jyufu\taogin_app\gulpfile.js     do   watch